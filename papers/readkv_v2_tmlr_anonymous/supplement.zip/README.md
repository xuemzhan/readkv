# Anonymous result replay

This supplement contains numeric evaluation ledgers. It reconstructs the manuscript tables on a CPU.

## Quick start

Use Python 3.10 or newer with NumPy. From the extracted directory run:

    python reproduce.py

The script reads evaluation.json, verifies the 720 harmonized historical labels, and regenerates results.json and results.tex. It computes exploratory percentile intervals from 10,000 resamples with the data seed as the bootstrap seed. L is stored as a fraction in JSON and displayed in percentage points in LaTeX.

The ledgers contain paired correctness, score or margin values, grouping labels and numeric SQuAD outcomes. They exclude original questions and document text, model weights, personal paths and checkpoints. The archive extraction mode additionally checks file manifests and the candidate-scoring forward audit when run from a full checkout. The standalone replay uses extracted audit counts.

The full-sequence tables apply the same first-candidate tie rule as the historical scorer and credit either candidate for A/B controls. Self has zero error relative to itself. The initial 2x2 comparisons and the scoring follow-up use separate archived score sets.
